# Marcus Finning
#DPW
#madlib


def madlib():
    print "hello and lets do a madlib" #welcome screen

    name = raw_input ("enter your name")
    verb = raw_input ("enter a verb")           #input itames
    adjective = raw_input ("enter a adjective")
    noun = raw_input ("enter a noun")
    city = raw_input ("enter a city name")

    print "once upone a time", name, noun, "was walking across the", verb, "and we came across a", adjective, "and we pull out our", noun,
    "and begin to fight", adjective, "and we were victorous in the fight with", name, noun, verb, "and we clontuned our walk to ", city #madlib story
